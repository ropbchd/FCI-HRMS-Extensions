# FCI HRMS Extensions — Master Registry

> **HOW TO USE THIS PACKAGE (read first)**
> This ZIP is the complete handover document for building and maintaining FCI HRMS Chrome extensions.
> When starting a new conversation to build or modify an extension:
> 1. Upload this ZIP
> 2. Tell Claude: "Read REGISTRY.md first, then read TECH_PATTERNS.md, then read the SPEC.md for the relevant extension."
> 3. Claude will be fully up to speed before you ask a single question.

---

## Quick Reference Table

| Extension Name | Request ID Prefix | Folder | Version | Status | Listing URL |
|---|---|---|---|---|---|
| NOC For Other Examination | NOE | `extensions/noc-other-examination/` | v4 | Stable | `/er/noc/other-examination` |
| NOC Passport | NOCPASS | `extensions/noc-passport/` | v1 | Stable | `/er/noc/passport` |
| Employee Profile Update | RHR | `extensions/employee-profile-update/` | v1.2 | Stable | `/corehr/transaction/profile-request` |

---

## Portal
- **URL:** hrmsfci.in
- **Full URL:** https://www.hrmsfci.in
- **System:** FCI Human Resource Management System (powered by Konnect)
- **User role building extensions for:** AMIT (MSS role — Manager Self Service)

## Repository
- GitHub: github.com/ropbchd/FCI-HRMS-Extensions
- All extensions are Chrome MV3 extensions (Manifest Version 3)

## People
- **AMIT KUMAR SINGH** — the officer using the extensions (MSS login)
- **MAYURESH KUMAR** — subordinate officer whose requests appear frequently
- **ABHIMANYU SWAMI** — subordinate officer

## Two Extension Architectures
There are two fundamentally different page architectures on the portal. Every new extension will follow one of these two patterns.

**Pattern A — NOC/Workflow (used by: NOC Exam, NOC Passport)**
- 3-page sequence: Listing → Review/Approval → Add Reviewer
- URLs: `/er/*/` or `/workflow/review/` and `/workflow/add-reviewer/`
- Stage detection required (multiple stages per request)
- sessionStorage used to pass data between pages

**Pattern B — Direct Approve (used by: Employee Profile Update)**
- 2-page sequence: Listing → Single approve page
- URLs: `/corehr/transaction/*/approve/*`
- No stage detection — officer decides outcome directly
- Tab navigation is full-page reload via `?tab=` URL parameter (NOT ajax)

---

## Adding a New Extension — Checklist
1. Run the interview protocol (see TECH_PATTERNS.md Section 5)
2. Determine which architecture pattern it follows (A or B above)
3. Create `extensions/<folder-name>/SPEC.md` using the template in TECH_PATTERNS.md
4. Copy source files from the closest matching existing extension as base
5. Update this REGISTRY.md table
6. Update TECH_PATTERNS.md if any new technical pattern is discovered
