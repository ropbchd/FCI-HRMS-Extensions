# SPEC — NOC Passport

## Identity
- Name: FCI NOC Passport Assistant
- Request ID prefix: NOCPASS
- Folder: `extensions/noc-passport/`
- Version: v1
- Architecture pattern: **A** (NOC / Workflow)
- Listing URL: `hrmsfci.in/er/noc/passport`
- Review URL pattern: `hrmsfci.in/workflow/review/<encoded-id>/<version>`
- Add Reviewer URL pattern: `hrmsfci.in/workflow/add-reviewer/<encoded-id>/<version>`

## Files
- `manifest.json`
- `content.js` — Review page script
- `content_add_reviewer.js` — Add Reviewer page script
- `content_passport_list.js` — Listing page script
- `popup.html`
- `icon.png`
- `CHANGELOG.md`

## What It Does (automatic steps)
1. Listing page: no action (passive)
2. Review page: detect stage → fill remark → open Annexure H automatically → navigate to Add Reviewer
3. Add Reviewer page: read sessionStorage → fill reviewer → submit

## Stage Detection
| Stage | Key sentence fragment | Action |
|---|---|---|
| 1 (New) | `New passport` + `Initiated` | Fill new passport Stage 1 remark |
| 1 (Renewal) | `Renewal` + `Initiated` | Fill renewal Stage 1 remark |
| 1B | `Forwarded by initiator` | Fill Stage 1B remark |
| 2 (New) | `New passport` + `Recommended by DO` | Fill new passport Stage 2 remark |
| 2 (Renewal) | `Renewal` + `Recommended by DO` | Fill renewal Stage 2 remark |
| 3 | `Recommended by RO` | Dynamic remark using employee name + designation + office |

## Preset Remarks
### Stage 3 (dynamic)
`"NOC is hereby granted to <EMPLOYEE NAME>, <DESIGNATION>, <OFFICE> for obtaining/renewing passport."`
Name, designation, and office are read live from the page.

### Other stages — see `content.js` REMARKS object for full text.

## Special Features
- **Annexure H auto-open:** on Stage 2 and 3, the Annexure H PDF link is automatically opened in a new tab
- **New vs Renewal variants:** Stage 1 and Stage 2 have different remarks depending on passport type
- **Dynamic Stage 3 remark:** pulls employee name, designation, office from the page at runtime

## Known Issues / Pending Tests
- Stage 1B not tested on live portal
- Passport table ID (`#passportTable`) needs live verification

## Version History
- v1 (May 2026) — initial release; based on NOC Other Examination v4 as template
