# Changelog — NOC For Other Examination Extension

All changes documented in reverse chronological order.

---

## v4 — May 2026 (Current)

**New feature: Stage 3B — send request back to DO when assistant raises objection**

- Added Stage 3B: triggers when the last assistant reviewed entry does NOT contain the "in order" key sentence (or contains its negation), next entry is AMIT KUMAR SINGH (Pending Review, N/A), and office ≠ RO CHANDIGARH.
- Identifies the DO Manager by finding the AGM entry with a non-N/A remark, then taking the entry immediately before it.
- Navigates to Add Reviewer with Office Type = DO (value "5"), selects the DO office and DO Manager by name.
- Remark: "Reference may be made to the observations recorded during examination of the request at Sl. No. [X]..." where [X] is the S.No. of the assistant's entry.

**New feature: Stage 3C — re-send to assistant after DO reprocesses**

- Added Stage 3C: triggers when the last substantive entry before AMIT KUMAR SINGH (Pending Review, N/A) is the same DO Manager identified by the AGM landmark method.
- Action: Add Reviewer → correct assistant (same cadre/office routing as Stage 2) with standard admin clearance remark.
- Creates the full loop: 3B → DO reprocesses → 3C → assistant rechecks → either Stage 3 (approved) or 3B again (another objection).

**Bug fix: Negative-safe Stage 3 key sentence check**

- Fixed a bug where "the said request has NOT been found to be in order" incorrectly triggered Stage 3 because `.includes()` matched the substring regardless of negation.
- Added a 25-character look-behind check: if the word "not" appears immediately before the key phrase, Stage 3 is suppressed and Stage 3B fires instead.

**Bug fix: Double-space in DO office names on Add Reviewer page**

- The portal stores DO office names with double spaces in the `<option>` tags (e.g. "DO  BHATINDA") while the Review page returns single-spaced names ("DO BHATINDA").
- Applied `.trim().replace(/\s+/g, ' ')` normalisation to both the option text and the target value inside `waitForDropdownAndSelect()` in `content_add_reviewer.js`.
- This extends the v3 fix (which was only in content.js) to the Add Reviewer page as well.

**Portal fact confirmed: Office Type dropdown values**
- Depot=6, DO=5, HQ=1, IFS=2, RO=4, ZO=3 (confirmed from portal inspector)

**Files changed:** `content.js`, `content_add_reviewer.js`

---

## v3 — May 2026

**Bug fix: Office name whitespace normalisation in content.js**

- Fixed a critical bug where Stage 2 routing failed for offices like "DO CHANDIGARH" because the portal stores office names with double spaces (e.g. "DO  CHANDIGARH").
- Applied `.trim().replace(/\s+/g, ' ')` normalisation at all four office comparison points in `content.js`.

**Files changed:** `content.js`

---

## v2 — May 2026

**Safety: Request type guard added to all three scripts**

- Added NOE prefix check at entry point of all three content scripts. Extension stays silent on all other request types sharing the same URL pattern.

**New feature: Stage 3**

- Added Stage 3: triggers when last assistant reviewed entry contains the "in order" key sentence and next entry is AMIT KUMAR SINGH (Pending Review, N/A).
- Fills Reviewer Remarks directly on the Review page — no navigation to Add Reviewer.
- Two remark variants: RO CHANDIGARH and all other offices.
- Stage priority order: Stage 3 → Stage 2 → Stage 1B → Stage 1 → no action.

**Files changed:** `content_noc_list.js`, `content.js`, `content_add_reviewer.js`

---

## v1 — May 2026

**Initial working version**

- `content_noc_list.js`: auto-opens first Pending Review NOE request on listing page.
- `content.js`: detects Stage 1 (ABHIMANYU SWAMI for vigilance), Stage 1B (RO CHANDIGARH variant), Stage 2 (assistant for admin clearance based on Cadre + Office routing).
- `content_add_reviewer.js`: fills Office Type, Office, Employee, Reason via sessionStorage handoff.
- Safety features: trigger flag, no auto-submission, no-match = no action, highlight before acting.
- Assistant routing: MADHU DHAKA (General), DIVYA KORNU (Depot Group 1), VISHALI MARWAHA (Depot Group 2).

**Files added:** `manifest.json`, `content_noc_list.js`, `content.js`, `content_add_reviewer.js`
