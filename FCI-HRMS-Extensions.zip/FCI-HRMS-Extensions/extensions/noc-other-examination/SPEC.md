# SPEC — NOC For Other Examination

## Identity
- Name: FCI NOC For Other Examination Assistant
- Request ID prefix: NOE
- Folder: `extensions/noc-other-examination/`
- Version: v4
- Architecture pattern: **A** (NOC / Workflow)
- Listing URL: `hrmsfci.in/er/noc/other-examination`
- Review URL pattern: `hrmsfci.in/workflow/review/<encoded-id>/<version>`
- Add Reviewer URL pattern: `hrmsfci.in/workflow/add-reviewer/<encoded-id>/<version>`

## Files
- `manifest.json`
- `content.js` — Review page script (stage detection + action)
- `content_add_reviewer.js` — Add Reviewer page script
- `content_noc_list.js` — Listing page script
- `popup.html`
- `icon.png`
- `CHANGELOG.md`

## What It Does (automatic steps)
1. **Listing page:** auto-clicks the Review button of the first pending NOE request.
2. **Review page:** clicks "View Action History", parses the action history table, detects the current stage, highlights the trigger row, and either navigates to Add Reviewer (Stages 1/1B/2/3B/3C) or fills Reviewer Remarks in-place (Stage 3).
3. **Add Reviewer page:** reads routing data from sessionStorage, fills Office Type + Office + Employee + Reason fields. Officer reviews and clicks Add manually.

## Key People
| Name | Emp No. | Role |
|---|---|---|
| MAYURESH KUMAR | 313929 | Dispatcher at RO CHANDIGARH — his Dispatched entry triggers Stage 1 |
| AMIT KUMAR SINGH | 276670 | Manager — his Pending Review + N/A entry is the confirmation condition for all stages |
| ABHIMANYU SWAMI | 276695 | Manager — Stage 1 recipient (vigilance clearance). His Reviewed entry triggers Stage 2 |
| MADHU DHAKA | 313284 | Assistant — handles General cadre (Stages 1B, 2, 3C) |
| DIVYA KORNU | 315172 | Assistant — handles Depot cadre, Group 1 offices (Stages 1B, 2, 3C) |
| VISHALI MARWAHA | 308235 | Assistant — handles Depot cadre, Group 2 offices (Stages 1B, 2, 3C) |

## Office Routing Groups
| Cadre | Group | Offices | Assistant |
|---|---|---|---|
| General | Any | All offices | MADHU DHAKA |
| Depot | Group 1 | RO CHANDIGARH, DO PATIALA, DO LUDHIANA, DO JALANDHAR, DO FARIDKOT, DO HOSHIARPUR, DO AMRITSAR | DIVYA KORNU |
| Depot | Group 2 | DO KAPURTHALA, DO FEROZEPUR, DO CHANDIGARH, DO BHATINDA, DO MOGA, DO GURDASPUR, DO SANGRUR | VISHALI MARWAHA |

## Stage Detection
Stage is determined by parsing the action history table on the Review page.
Each entry is an object: `{ slNo, actionTaken, employeeName, designation, remark }`.

| Stage | Trigger condition | Action |
|---|---|---|
| **1** | Last Dispatched = MAYURESH KUMAR + next = AMIT (Pending Review, N/A) + office ≠ RO CHANDIGARH | Add Reviewer → ABHIMANYU SWAMI. Remark: vigilance clearance request. |
| **1B** | Same as Stage 1 but office = RO CHANDIGARH | Add Reviewer → correct assistant (cadre/office routing). Remark: performa request. |
| **2** | Last Reviewed = ABHIMANYU SWAMI + next = AMIT (Pending Review, N/A) | Add Reviewer → correct assistant (cadre/office routing). Remark: admin clearance request. |
| **3** | Last Reviewed = one of three assistants + remark contains key sentence (NOT negated) + next = AMIT (Pending Review, N/A) | Fill Reviewer Remarks in-place (no navigation). Remark: final approval text. |
| **3B** | Last Reviewed = one of three assistants + remark does NOT contain key sentence (or negated) + next = AMIT (Pending Review, N/A) + office ≠ RO CHANDIGARH | Add Reviewer → DO Manager (entry immediately before AGM with non-N/A remark). Office Type = DO. Remark: reference to assistant's S.No. |
| **3C** | Last entry before AMIT (Pending Review, N/A) = the same DO Manager identified for 3B | Add Reviewer → correct assistant (cadre/office routing). Remark: admin clearance request. |

**Stage priority order (first match wins):** 3 → 3B → 3C → 2 → 1B → 1 → no match

## Stage 3 Key Sentence (negative-safe check)
```
"the said request has been found to be in order and in accordance with the applicable policies, circulars, and advisories presently in"
```
The check looks 25 characters before this phrase for the word "not". If found → Stage 3 is suppressed and Stage 3B fires instead.

## AGM Landmark (used by Stage 3B and 3C)
- Find the one action history entry where `designation = "Assistant General Manager"` AND `remark` is non-empty and not "N/A".
- The **DO Manager** = the entry immediately before that AGM entry in the array.

## Office Type Values (Add Reviewer page — #filter_office_type)
| Label | value= |
|---|---|
| Depot | 6 |
| DO | 5 |
| HQ | 1 |
| IFS | 2 |
| RO | 4 |
| ZO | 3 |

## Preset Remarks
### Stage 1
`With respect to the application made by the employee, kindly provide the vigilance clearance for the purpose of NOC for other exam.`

### Stage 1B
`Kindly provide the details as per the performa provided by the FCI, Zonal Office (N).`

### Stage 2 and 3C
`Kindly review for admin. clearance and check for the details.`

### Stage 3 (non-RO CHANDIGARH)
`With reference to the application for a No Objection Certificate (NOC) to appear in another examination, it is respectfully submitted that the employee is clear from the vigilance perspective at the Divisional Office and Regional Office, and the administrative clearances from the Divisional and Regional Offices are also in place. The request is in compliance with the previously issued advisory on such matters. In view of the above, and considering that all requisite clearances have been duly obtained, if agreed, the NOC for appearing in the said examination may kindly be approved.`

### Stage 3 (RO CHANDIGARH)
`With reference to the application for a No Objection Certificate (NOC) to appear in another examination, it is respectfully submitted that the employee is clear from the vigilance  and administrative perspective at  Regional Office, level. The request is in compliance with the previously issued advisory on such matters. In view of the above, and considering that all requisite clearances have been duly obtained, if agreed, the NOC for appearing in the said examination may kindly be approved.`

### Stage 3B
`Reference may be made to the observations recorded during examination of the request at Sl. No. [X]. Required necessary clarifications and/or supporting documents, as indicated, may kindly be furnished for further processing.`
(where [X] = slNo of the last assistant's reviewed entry)

## sessionStorage Keys
| Key | Purpose |
|---|---|
| fci_noc_triggered | Safety flag — "yes" = extension triggered Add Reviewer |
| fci_noc_stage | Stage detected: "1", "1b", "2", "3b", "3c" |
| fci_noc_office_type | Office Type value: "4" (RO) or "5" (DO) |
| fci_noc_assistant_emp | Emp number (RO-level employees) |
| fci_noc_assistant_name | Employee name (for logging) |
| fci_noc_assistant_remark | Remark text for Reason field |
| fci_noc_target_office | DO office name (Stage 3B only) |
| fci_noc_target_employee_name | DO employee name for name-based selection (Stage 3B only) |

## Known Issues / Pending Tests
- Stage 1B: code complete but never tested on a live request. Verify on first occurrence.
- Stage 3C: designed and coded but not yet tested on a live request. Verify on first occurrence.
- The RO CHANDIGARH Stage 3 remark has two intentional double-spaces ("vigilance  and", "at  Regional"). Do NOT correct these.

## Version History
- v1 (May 2026) — initial: Stages 1, 1B, 2
- v2 (May 2026) — added Stage 3; NOE prefix safety guard on all scripts
- v3 (May 2026) — fixed double-space bug in office name matching in content.js
- v4 (May 2026) — added Stages 3B and 3C; negative-safe Stage 3 key sentence check; fixed double-space bug in content_add_reviewer.js waitForDropdownAndSelect(); Office Type values confirmed from portal inspector
