# SPEC — Employee Profile Update

## Identity
- Name: FCI Employee Profile Update Assistant
- Request ID prefix: RHR
- Folder: `extensions/employee-profile-update/`
- Version: v1.2
- Architecture pattern: **B** (Direct Approve)
- Listing URL: `hrmsfci.in/corehr/transaction/profile-request`
- Approve URL pattern: `hrmsfci.in/corehr/transaction/profile-request/approve/<encoded-id>?tab=req_history`

## Files
- `manifest.json`
- `content_approve.js` — Approve page script (tab check + attachment + floating panel)
- `content_list.js` — Listing page script (closes attachment tab on return)
- `background.js` — Service worker (background tab open + close)
- `popup.html`
- `icon.png`
- `CHANGELOG.md`

## What It Does (automatic steps)
1. **Approve page load:**
   - Verify Request ID starts with `RHR` — if not, do nothing
   - Check `?tab=` URL param — if not `req_history`, navigate once to `?tab=req_history`
   - Open Attachment "view" link in background tab via `chrome.tabs.create({ active: false })`
   - Inject floating remark panel (draggable, top-right corner)
2. **Listing page load:**
   - Read `epu_attachment_tab_id` from sessionStorage
   - If found, send `closeTab` message to background.js → attachment tab closes

## Floating Panel
- **Green section:** 3 Approve remarks
- **Red section:** 3 Reject remarks
- Click a remark → previews full text at bottom of panel
- "Fill remark" button → fills `#dop_member_comment` textarea on the page
- Panel is draggable by its header
- For non-standard remarks: officer types directly into Approver Remarks box on the page

## Preset Approve Remarks
1. `Approved and record updated based on the supporting document provided.`
2. `Approved and record updated as per request.`
3. `Approved and record updated as per request based on the documents available in the personal file of the officer concerned.`

## Preset Reject Remarks
1. `Kindly apply though appropriate channel/module as this information cannot be updated through the employee profile module.`
2. `The officer may be asked to apply though appropriate channel as this request cannot be processed by this module.`
3. `Kindly provide the supporting documents for substantiating the request made.`

## How to Add / Edit Remarks
Open `content_approve.js`. Edit `APPROVE_REMARKS` or `REJECT_REMARKS` arrays at the top of the file.
Each entry: `{ label: 'Button text', full: 'Full text filled into form' }`
After saving → go to `chrome://extensions` → click reload on the extension → refresh HRMS page.

## Tab Navigation — Key Discovery
Clicking `.change-tab` element triggers `window.location.href` navigation (full page reload).
Calling `.click()` on the tab causes an infinite loop. See TECH_PATTERNS.md Section 2.

## Known Issues / Pending
- Remarks list is intentionally small (6 presets). Expand as needed using the instructions above.
- Page always lands on Update tab directly (bypasses Profile tab) — acceptable behaviour.

## Version History
- v1.0 — initial. Tab infinite loop bug. Attachment stealing focus. Attachment re-opening on tab switch.
- v1.1 — fixed tab selector. Added `window.focus()` after `window.open()`. Added sessionStorage guard. Tab loop fixed; attachment still stealing focus.
- v1.2 (current, stable) — replaced `.click()` with URL param check. Replaced `window.open()` with `chrome.tabs.create({ active: false })` via background script. All issues resolved.
