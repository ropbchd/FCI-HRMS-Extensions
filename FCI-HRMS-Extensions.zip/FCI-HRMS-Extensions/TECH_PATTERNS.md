# FCI HRMS Extensions — Technical Patterns Reference

All confirmed technical facts about hrmsfci.in. Update this file whenever a new pattern is discovered.

---

## 1. Page Architecture — Pattern A (NOC / Workflow)

### URL Patterns
- Listing: `/er/noc/<request-type>` (e.g. `/er/noc/other-examination`)
- Review page: `/workflow/review/<encoded-id>/<version>`
- Add Reviewer page: `/workflow/add-reviewer/<encoded-id>/<version>`

### Navigation
- Review page → Add Reviewer page: click `#view_action_history` button
- Add Reviewer page → back to listing: after form submit, redirect is automatic
- Stage detection: read `#key_sentence` hidden input value on the Review page

### Key Element IDs (Pattern A)
```
#key_sentence          — hidden input; contains stage-detection text
#dop_member_comment    — Approver/Reviewer remarks textarea (SAME ID on both pages)
#view_action_history   — "View Action History" button → navigates to Add Reviewer page
#approve_submit        — Approve/Submit button
#reject_submit         — Reject button
#add_reviewer          — Add Reviewer dropdown (Select2)
#submit_reviewer       — Submit reviewer button
```

### sessionStorage Keys (Pattern A)
```
fci_noc_triggered      — set on Review page, read on Add Reviewer page to trigger auto-fill
fci_noc_request_id     — passed from Review to Add Reviewer page
fci_noc_remark         — remark text passed from Review to Add Reviewer page
```

### Select2 Dropdown Filling
```javascript
// Select2 dropdowns cannot be filled with .value = x
// Correct method:
const $select = $(selector);
$select.val(optionValue).trigger('change');
// If options not yet loaded, use ajax trigger or search input method
```

### Office Type Dropdown Values (#filter_office_type on Add Reviewer page)
Confirmed from portal inspector:
| Label | value= |
|---|---|
| Depot | 6 |
| DO (Divisional Office) | 5 |
| HQ | 1 |
| IFS | 2 |
| RO (Regional Office) | 4 |
| ZO | 3 |

### Office Name Whitespace Normalisation
The portal stores office names with double spaces in both `<option>` tags and action history cells (e.g. "DO  BHATINDA", "DO  CHANDIGARH"). Always normalise before comparing:
```javascript
const normalise = s => s.trim().replace(/\s+/g, ' ').toUpperCase();
// Use normalise() on both the stored value and the DOM text before .includes()
```

### Stage Detection Algorithm
Read `#key_sentence` value on the Review page. Match against known strings to determine stage (1, 1B, 2, 3, 3B, 3C). See individual SPEC.md files for the exact strings per extension.

---

## 2. Page Architecture — Pattern B (Direct Approve)

### URL Patterns
- Listing: `/corehr/transaction/<request-type>` (e.g. `/corehr/transaction/profile-request`)
- Approve page: `/corehr/transaction/<request-type>/approve/<encoded-id>?tab=<tab-name>`

### Tab Navigation — CRITICAL
The approve page has multiple tabs (e.g. Profile / Portfolio / Service Book / Update).
**Tab switching is a FULL PAGE RELOAD, not AJAX.**
The site's handler: `$(".change-tab").on("click", function() { window.location.href = url + "?tab=" + $(this).data('name'); })`

**NEVER call `.click()` on a tab element — it causes an infinite reload loop.**

Correct approach:
```javascript
const tabParam = new URL(window.location.href).searchParams.get('tab');
if (tabParam !== 'req_history') {
  window.location.href = window.location.href.split('?')[0] + '?tab=req_history';
}
// If already on correct tab → do nothing
```

### Key Element IDs (Pattern B — EPU)
```
#dop_member_comment    — Approver Remarks textarea (same ID as Pattern A)
#approve_submit        — Approve button
#reject_submit         — Reject button
#frm-approver          — the form element
```

### Attachment Link Selector
```javascript
// <li><label>Attachment </label><span><a href="...get-file?path=...">view</a></span></li>
const listItems = document.querySelectorAll('li');
for (let li of listItems) {
  const label = li.querySelector('label');
  if (label && label.textContent.trim().toLowerCase().startsWith('attachment')) {
    const link = li.querySelector('a');
    // link.href is the attachment URL
  }
}
```

---

## 3. Cross-Pattern Technical Facts

### Opening a Tab in Background (Without Stealing Focus)
`window.open()` ALWAYS steals focus in Chrome. `window.focus()` after it does NOT reliably restore focus.

**Only reliable method:** use background service worker.
```javascript
// content script:
chrome.runtime.sendMessage({ action: 'openTabInBackground', url: link.href }, function(response) {
  sessionStorage.setItem('attachment_tab_id', response.tabId);
});

// background.js:
if (message.action === 'openTabInBackground') {
  chrome.tabs.create({ url: message.url, active: false }, function(tab) {
    sendResponse({ tabId: tab.id });
  });
  return true;
}
```

### Closing a Tab via Background Script
```javascript
// content script:
chrome.runtime.sendMessage({ action: 'closeTab', tabId: parseInt(storedTabId) });

// background.js:
if (message.action === 'closeTab') {
  chrome.tabs.remove(message.tabId, function() { sendResponse({ success: true }); });
  return true;
}
```

### Filling a Textarea and Triggering Framework Events
```javascript
textarea.value = text;
textarea.dispatchEvent(new Event('input',  { bubbles: true }));
textarea.dispatchEvent(new Event('change', { bubbles: true }));
```

### Request ID Detection
```javascript
// Pattern A and B both use this structure:
// <li><label>Request ID</label><span>XXX123456</span></li>
const listItems = document.querySelectorAll('li');
for (let li of listItems) {
  const label = li.querySelector('label');
  const span  = li.querySelector('span');
  if (label && span && label.textContent.trim().toLowerCase().includes('request id')) {
    return span.textContent.trim().toUpperCase();
  }
}
```

### Manifest V3 Requirements
- Background scripts must be declared as `"service_worker"` not `"scripts"`
- `chrome.tabs` API requires `"tabs"` permission in manifest
- Content scripts cannot use `chrome.tabs` directly — must message background script
- `host_permissions` must cover both `https://www.hrmsfci.in/*` and `https://hrmsfci.in/*`

---

## 4. Common Pitfalls

| Pitfall | Symptom | Fix |
|---|---|---|
| Clicking `.change-tab` element | Infinite page reload loop | Use URL param check + `window.location.href` navigation |
| `window.open()` for attachment | Attachment tab steals focus | Use `chrome.tabs.create({ active: false })` via background script |
| Forgetting one-open guard | Attachment re-opens on every tab switch | Set `sessionStorage` flag keyed to requestId after first open |
| `window.open` tab ID tracking | Wrong tab gets closed | Use `chrome.tabs.create` callback — it returns the exact tab.id |
| Select2 filled with `.value` | Dropdown appears empty | Use `$(selector).val(v).trigger('change')` |
| Portal office names have double spaces | `waitForDropdownAndSelect()` never matches (e.g. "DO  BHATINDA" vs "DO BHATINDA") | Normalise both sides: `opt.textContent.trim().replace(/\s+/g, ' ')` and `targetValue.trim().replace(/\s+/g, ' ')` |
| Stage 3 key sentence negated | "NOT in order" incorrectly triggers Stage 3 | Check 25 chars before key phrase for word "not": `const pre = remark.substring(Math.max(0,idx-25),idx); return !(/\bnot\b/.test(pre));` |
| `#dop_member_comment` not found | Fill fails silently | Scroll to bottom first; the element may be off-screen and not yet rendered |
| Stray paragraph after `<w:sectPr>` in docx | Word XML validation error | Always insert new content before `<w:sectPr>`, never after |

---

## 5. Interview Protocol for New Extensions

Ask these questions before writing a single line of code:

1. **Request type name** and listing page URL
2. **Approve/Review page URL** — share a screenshot showing the address bar
3. **Action icon** on listing page — eye? checkmark? "Review" button?
4. **Page structure** — is it Pattern A (workflow/review) or Pattern B (direct approve)?
5. **What should the extension do automatically** on page load?
6. **Remarks** — what are the preset approve and reject remarks?
7. **Attachment** — is there one? Should it auto-open?
8. **Confirmation dialogs** — does Approve/Reject show a confirm popup?
9. **Upload the page HTML source** — right-click → Save As on the approve page

---

## 6. SPEC.md Template for New Extensions

Copy this template when creating a new extension's SPEC.md:

```markdown
# SPEC — <Extension Name>

## Identity
- Name: 
- Request ID prefix: 
- Folder: extensions/<folder>/
- Version: v1
- Architecture pattern: A or B
- Listing URL: 
- Approve/Review URL pattern: 

## Files
- manifest.json
- content_<name>.js  (approve/review page)
- content_<name>_list.js  (listing page, if needed)
- background.js  (if tabs API needed)
- popup.html

## What It Does (automatic steps)
1. 
2. 

## Stage Detection (Pattern A only)
| Stage | Key sentence fragment | Action |
|---|---|---|

## Preset Remarks
### Approve
1. 

### Reject
1. 

## Known Issues / Pending Tests
- 

## Version History
- v1 — initial
```
